<?php
/**
 * To integrate Stripe as a payment option for users,
 * admins must have access to an active Stripe account
 * and they must create a "product" with the price equal
 * to one entry.
 * 
 * In Site Preferences, provide:
 *  - API Keys
 *  - Entry fee "product"
 * 
 *  
 */

$stripe_product_key = "price_1JeTKqFEb4Q4EIfcGkFprDuT";
$stripe_api_key_public = "pk_test_51JeRMBFEb4Q4EIfcbdGOAB2mDe3KyqlqOXolpUg8XclmdTnfvdS7urt7oksjy34IPzSzCcDj9dLz46iCA2eE6naj00ODB9SsDj";
$stripe_api_key_secret = "sk_test_51JeRMBFEb4Q4EIfcaszKf116MWtoMgF3Sn9r0MzwgAcZm794vyyZ8cAf7ftqyfXHnlfHwJOlHfm99i8mRvjWRYEw00e0umuBM2";

?>